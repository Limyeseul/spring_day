package org.comstudy21.myapp.util;

public interface JdbcProperties {
	String CLASS_DRIVER = "org.h2.Driver";
	String URL = "jdbc:h2:tcp://localhost/~/test";
	String USER = "sa";
	String PASSWORD = "";
}
