package org.comstudy21.myapp.board.dao;

import java.util.List;

import org.comstudy21.myapp.board.vo.BoardVo;

public interface Dao {
	//SQL 명령어들
	String BOARD_INSERT = "insert into board(seq,title,writer,content) "+
					"values((select nvl(max(seq),0)+1),?,?,?)";
	String BOARD_UPDATE = "update board set tittle=?, content=? where seq=?";
	String BOARD_DELETE = "delete from board where seq=?";
	String BOARD_GET = "select * from board where seq=?";
	String BOARD_LIST = "select * from board order by seq desc";
	//글 입력
	void insertBoard(BoardVo vo);
	//글 수정
	void updateBoard(BoardVo vo);
	//글 삭제
	void deleteBoard(BoardVo vo);
	//상세 조회
	BoardVo getBoard(BoardVo vo);
	//글 목록 조회
	List<BoardVo> getBoardList(BoardVo vo);
}
